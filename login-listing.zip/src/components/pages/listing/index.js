import React from "react";
import { Navigate, useNavigate } from "react-router-dom";
import Header from "../Header";
import Footer from "../Footer";

const Listing = () => {
  const data = [
    { id: 1, name: "item1", discription: "abc" },
    { id: 2, name: "item2", discription: "def" },
    { id: 3, name: "item3", discription: "ghi" },
  ];

  let navigate = useNavigate();
  const changeRoute = () => {
    let path = "/Form";
    navigate(path);
  };
  return (
    <>
      <Header />
      <section className="listing">
        <div className="container-fluid">
          <div className="text-center d-flex justify-content-end">
            <button
              type="submit"
              className="btn btn-primary mt-4"
              onClick={changeRoute}
            >
              ADD NEW
            </button>
          </div>
          <table className="table border">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">ItemName</th>
                <th scope="col">Discription</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item) => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.name}</td>
                  <td>{item.discription}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Listing;
