import React from "react";

const Footr = () => {
  return (
    <>
      <section className="lastfooter d-flex justify-content-center align-items-end">
        <div className="container-fuid">
          <p className="lfpara h-100 text-center">
            © 2024 Doctor On Demand by Included Health, Inc. All rights
            reserved.
          </p>
        </div>
      </section>
    </>
  );
};

export default Footr;
