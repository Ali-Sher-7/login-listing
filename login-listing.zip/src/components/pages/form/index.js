import React, { useState } from "react";
import Header from "../Header";
import Footer from "../Footer";

const Form = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [username, setUsername] = useState("");
  const [groupId, setGroupid] = useState("");
  const [department, setDepartment] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("mail:", email);
  };

  return (
    <>
      <Header />
      <section className="form">
        <form className="m-5" onSubmit={handleSubmit}>
          <div className="form-row justify-content-around">
            <div className="form-group col-md-5">
              <label htmlFor="inputAddress">First Name</label>
              <input
                type="text"
                className="form-control"
                id="fname"
                placeholder="First Name"
                value={fname}
                onChange={(e) => setFname(e.target.value)}
                required
              />
            </div>
            <div className="form-group col-md-5">
              <label htmlFor="inputAddress2">Last Name</label>
              <input
                type="text"
                className="form-control"
                id="lname"
                placeholder="Last Name"
                value={lname}
                onChange={(e) => setLname(e.target.value)}
                required
              />
            </div>

            <div className="form-group col-md-5">
              <label htmlFor="inputCity">User Name</label>
              <input
                type="text"
                className="form-control"
                id="username"
                placeholder="User Name"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="form-group col-md-5">
              <label htmlFor="inputEmail4">Email</label>
              <input
                type="email"
                className="form-control"
                id="inputEmail4"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="form-group col-md-5">
              <label htmlFor="inputPassword4">Password</label>
              <input
                type="password"
                className="form-control"
                id="inputPassword4"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div class="form-group col-md-5">
              <label for="disabledSelect" class="form-label">
                Group ID
              </label>
              <select
                id="disabledSelect"
                class="form-select"
                value={groupId}
                onChange={(e) => setGroupid(e.target.value)}
                required
              >
                <option>Group ID 1</option>
                <option>Group ID 2</option>
                <option>Group ID 3</option>
                <option>Group ID 4</option>
              </select>
            </div>
            <div class="form-group col-md-12">
              <label for="disabledSelect" class="form-label">
                Department
              </label>
              <select
                id="disabledSelect"
                class="form-select"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                required
              >
                <option>Department 1</option>
                <option>Department 2</option>
                <option>Department 3</option>
                <option>Department 4</option>
              </select>
            </div>
            <div className="form-group col-md-12">
              <button type="submit" className="btn btn-primary">
                ADD
              </button>
            </div>
          </div>
        </form>
      </section>
      <Footer />
    </>
  );
};

export default Form;
