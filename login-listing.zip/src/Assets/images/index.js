import usersImg from "./usersImg.png";
import bg01 from "./bg01.jpg";
import bg02 from "./bg02.jpg";
import bg03 from "./bg03.jpg";
export const Images = {
  usersImg: usersImg,
  bg01: bg01,
  bg02: bg02,
  bg03: bg03,
};
